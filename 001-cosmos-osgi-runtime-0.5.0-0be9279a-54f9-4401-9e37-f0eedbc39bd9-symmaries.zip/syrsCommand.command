#!/bin/bash
dir="/tmp/scan-iawbnpwd/out";
syrsvers="$(symmaries/_build/src/main/syrs.native -V)";
if test -r "${dir}/results${variant}.syrs-version"; then oldvers="$(< "${dir}/results${variant}.syrs-version")"; else oldvers="none"; fi;
if [ "$oldvers" != "$syrsvers" ]; then
   OCAMLRUNPARAM="h=3G" symmaries/_build/src/main/syrs.native -ll w -tf -exceptions,-taints,levels=all,heapdom=deepalias "${dir}/types.classes" -o "${dir}/types.classes_bin" -o "${dir}/types.class_stats" && OCAMLRUNPARAM="h=3G" symmaries/_build/src/main/syrs.native -ll w -tf -exceptions,-taints,levels=all,heapdom=deepalias "${dir}/types.classes_bin" "${dir}/Meth/all.secstubs" "${dir}/Meth/all.meth_files" -of scfg,secsum,secsum_bin -rf -dr -rf cuddmem=4GiB -pf timeout=5m --methskip-cond 300 --combined-scfg-output "${dir}/combined-scfg.dot" --safe-walk -o "${dir}/results${variant}.secsums" -o "${dir}/results${variant}.secsums_bin" -o "${dir}/results${variant}.meth_stats" && echo "$syrsvers" > "${dir}/results${variant}.syrs-version"
fi
